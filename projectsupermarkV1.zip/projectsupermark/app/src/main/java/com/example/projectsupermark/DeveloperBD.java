package com.example.projectsupermark;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DeveloperBD extends SQLiteOpenHelper {

    private static final String NOMBRE_BD="tienda.bd";
    private static final int VERSION_BD=1;
    private static final String TABLA_PRODUCTOS="CREATE TABLE PRODUCTOS(CODIGO INT PRIMARY KEY, NOMBRE TEXT, PRECIO INT";

    public DeveloperBD(@Nullable Context context) {
        super(context, NOMBRE_BD,  null , VERSION_BD);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        SQLiteDatabase.execSQL(TABLA_PRODUCTOS);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        SQLiteDatabase.execSQL("DROP TABLE IF EXISTS"+TABLA_PRODUCTOS);
        SQLiteDatabase.execSQL(TABLA_PRODUCTOS);
    }

    public void agregarregistros(String codigo, String nombre, String precio){
        SQLiteDatabase bd=getWritableDatabase();
        if (bd!=null){
            bd.execSQL("INSERT INTO CURSOS VALUES('"+codigo+"','"+nombre+"','"+precio+"')");
            bd.close();
        }
    }
}

