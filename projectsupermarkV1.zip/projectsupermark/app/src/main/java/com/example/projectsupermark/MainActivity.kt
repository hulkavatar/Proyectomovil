package com.example.projectsupermark

import android.os.Bundle
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import java.util.*

class MainActivity : AppCompatActivity() {

    EditText editcodigo,edtProducto,edtPrecio;
    Button AddBtn;

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        edtProducto=(EditText)findViewById(R.id.edtCodigo)
    }
}