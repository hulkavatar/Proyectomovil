package com.example.supermercado.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.supermercado.MainViewModel
import com.example.supermercado.Product
import com.example.supermercado.R
import com.example.supermercado.adapters.ProductListAdapter
import com.example.supermercado.databinding.FragmentProductosBinding
import java.util.*

class ProductosFragment : Fragment() {

    private var adapter:ProductListAdapter? = null
    companion object {
        fun newInstance() = ProductosFragment()
    }

    private val viewModel: MainViewModel by viewModels()
    private var _binding:FragmentProductosBinding? = null
    private val binding get() = _binding!!


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //viewModel = ViewModelProvider(this).get(MainViewModel::class.java)

    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentProductosBinding.inflate(inflater,container,false)
        return  binding.root
        //return inflater.inflate(R.layout.fragment_main, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        listenerSetup()
        observerSetup()
        recyclerSetup()
    }


    //Adding the Button Listeners
    private fun listenerSetup(){
        binding.addBtn.setOnClickListener {
            val name = binding.productName.text.toString()
            val quantity = binding.productQuantity.text.toString()
            if(name != "" && quantity != ""){
                val product= Product(name,Integer.parseInt(quantity))
                viewModel.insertProduct(product)
                clearFields()
            }else{
                binding.productMsg.text="Incomplete Information"
            }
        }


        binding.findBtn.setOnClickListener {
            viewModel.findProduct(binding.productName.text.toString())
        }


        binding.deleteBtn.setOnClickListener {
            viewModel.deleteProduct(binding.productName.text.toString())
            clearFields()
        }


    }

    //Adding LiveData Observers
    private fun observerSetup() {
        viewModel.getAllProducts()?.observe(viewLifecycleOwner) { products ->
            products?.let {
                adapter?.setProductList(it)

            }
        }


        viewModel.getSearchResults().observe(viewLifecycleOwner){
                products-> products?.let {
            if(it.isNotEmpty()){
                binding.productMsg.text= String.format(Locale.US,"%d",it[0].id)
                binding.productName.setText(it[0].productName)
                binding.productQuantity.setText(String.format(Locale.US,"%d",it[0].quantity))

            }else{
                binding.productMsg.text="No Match"
            }
        }
        }


    }

    //Initializing the RecyclerView
    private fun recyclerSetup(){
        adapter = ProductListAdapter(R.layout.product_list_item)
        binding.productRecycler.layoutManager = LinearLayoutManager(context)
        binding.productRecycler.adapter = adapter
    }

    //Clear visual components on UI
    private fun clearFields(){
        binding.productMsg.text=""
        binding.productName.setText("")
        binding.productQuantity.setText("")
    }
}