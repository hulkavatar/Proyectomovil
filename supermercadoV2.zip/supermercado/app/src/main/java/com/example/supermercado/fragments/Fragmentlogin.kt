package com.example.supermercado.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.Toast
import androidx.navigation.Navigation
import com.example.supermercado.R
import com.example.supermercado.databinding.FragmentFragmentloginBinding


class Fragmentlogin : Fragment() {

    //Con esta variable binding lo que hacemos es asignarle para que pueda recibir valores nulos
    private var _binding: FragmentFragmentloginBinding? = null
    private val binding get() = _binding!!

    //Estados del fragment son dos, el de creado y el de destruido
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        //Con el binding lo unico que estamos haciendo es la conexion con la programacion y el XMLx
        //Para ingresar el binding
        _binding =
            FragmentFragmentloginBinding.inflate(inflater)
        val vista = binding.root

        //Cuando pulse el boton ingresar, lo redirigira a la otra vista
        val ingresar = binding.BtnIngresar
        ingresar.setOnClickListener {
            //Asignacion de las variables para usuario y password
            val user: EditText = binding.EditUsuario
            val pass: EditText = binding.EditPassword

            //Validacion del usuario
            if (user.text.toString() == "admin" && pass.text.toString() == "admin"){
                Toast.makeText(requireContext(), "BIENVENIDO CLIENTE", Toast.LENGTH_SHORT).show()
                Navigation.findNavController(vista).navigate(R.id.action_fragmentlogin_to_productosFragment)
            }else{
                Toast.makeText(requireContext(), "INGRESA TUS CREDENCIALES CORRECTAS", Toast.LENGTH_SHORT).show()
            }
        }
        return vista
    }

}