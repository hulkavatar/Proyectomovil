package data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.supermercado.Product

@Database(entities = [(Product::class)], version = 1)
abstract class database : RoomDatabase() {

    abstract fun productDao(): ProductDao
    companion object {
        private var INSTANCE:database? = null
        internal fun getDatabase(context: Context) : database? {
            if(INSTANCE == null){
                synchronized(database::class.java){
                    if (INSTANCE == null){
                        INSTANCE =
                            Room.databaseBuilder(
                                context.applicationContext,
                                database::class.java,
                                "product_database").build()
                    }
                }
            }
            return INSTANCE
        }
    }
}